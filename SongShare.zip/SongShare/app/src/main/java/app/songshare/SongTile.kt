package app.songshare

import android.app.PendingIntent
import android.content.Intent
import android.graphics.drawable.Icon
import android.os.Build
import android.provider.Settings
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

class SongTile : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        val t = qsTile ?: return
        t.label = "Song Share"
        t.icon = Icon.createWithResource(this, R.drawable.ic_tile)
        t.state = Tile.STATE_INACTIVE
        t.updateTile()
    }

    private fun listenerOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return s.contains(packageName)
    }

    override fun onClick() {
        super.onClick()
        val i = if (listenerOn()) {
            Intent(this, MainActivity::class.java).setAction(MainActivity.ACTION_NOW_PLAYING)
        } else {
            Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
        }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (Build.VERSION.SDK_INT >= 34) {
            startActivityAndCollapse(PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE))
        } else {
            @Suppress("DEPRECATION")
            startActivityAndCollapse(i)
        }
    }
}
