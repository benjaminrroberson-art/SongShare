package app.songshare

import android.service.notification.NotificationListenerService

// Empty on purpose: having this service enabled in "Notification access" is what
// lets Song Share read the active media session (title, artist, album).
class NowPlayingListener : NotificationListenerService()
