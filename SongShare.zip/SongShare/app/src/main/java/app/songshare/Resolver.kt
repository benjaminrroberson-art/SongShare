package app.songshare

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.text.Html
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

enum class Kind(val label: String, val entity: String) {
    SONG("Song", "song"),
    ALBUM("Album", "album"),
    ARTIST("Artist", "musicArtist")
}

enum class Svc(val label: String, val color: Int, val hosts: List<String>, val base: String) {
    APPLE("Apple Music", 0xFFFA243C.toInt(), listOf("music.apple.com", "itunes.apple.com"), "https://music.apple.com/us/search?term="),
    SPOTIFY("Spotify", 0xFF1DB954.toInt(), listOf("spotify.com", "spotify.link"), "https://open.spotify.com/search/"),
    YTM("YouTube Music", 0xFFE62117.toInt(), listOf("youtube.com", "youtu.be"), "https://music.youtube.com/search?q="),
    AMAZON("Amazon Music", 0xFF1BA8B3.toInt(), listOf("music.amazon", "amazon."), "https://music.amazon.com/search/"),
    TIDAL("Tidal", 0xFF3A4048.toInt(), listOf("tidal.com"), "https://tidal.com/search?q="),
    DEEZER("Deezer", 0xFFA238FF.toInt(), listOf("deezer.com", "deezer.page.link", "dzr.page.link"), "https://www.deezer.com/search/"),
    SOUNDCLOUD("SoundCloud", 0xFFFF5500.toInt(), listOf("soundcloud.com", "on.soundcloud"), "https://soundcloud.com/search?q=");

    fun search(q: String): String = base + Uri.encode(q)
}

data class Item(
    val kind: Kind,
    val title: String,
    val artist: String,
    val album: String,
    val art: String?,
    val appleUrl: String?
)

class LinkRow(val svc: Svc, val url: String, val exact: Boolean, val note: String)

object Resolver {
    class Result(val item: Item?, val source: Svc?, val origUrl: String?, val note: String)

    private const val UA =
        "Mozilla/5.0 (Linux; Android 14; Pixel) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"

    // ---------- network ----------

    fun get(url: String): String? {
        return try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 8000
            c.readTimeout = 8000
            c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", UA)
            c.setRequestProperty("Accept-Language", "en-US,en;q=0.9")
            if (c.responseCode !in 200..299) null
            else c.inputStream.bufferedReader().use { it.readText() }
        } catch (e: Exception) {
            null
        }
    }

    private fun getJson(url: String): JSONObject? {
        val s = get(url) ?: return null
        return try {
            JSONObject(s)
        } catch (e: Exception) {
            null
        }
    }

    fun bitmap(url: String): Bitmap? {
        return try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 8000
            c.readTimeout = 8000
            c.setRequestProperty("User-Agent", UA)
            c.inputStream.use { BitmapFactory.decodeStream(it) }
        } catch (e: Exception) {
            null
        }
    }

    // ---------- names ----------

    private fun norm(s: String): String = s.lowercase()
        .replace(Regex("\\s-\\s(single|ep)$"), "")
        .replace(Regex("\\(.*?\\)|\\[.*?\\]"), "")
        .replace("&", "and")
        .replace(Regex("[^\\p{L}\\p{N} ]"), "")
        .replace(Regex("\\s+"), " ")
        .trim()

    fun sameName(a: String, b: String): Boolean {
        val x = norm(a)
        val y = norm(b)
        return if (x.isEmpty() || y.isEmpty()) a.trim().equals(b.trim(), true) else x == y
    }

    private fun looseName(a: String, b: String): Boolean {
        if (sameName(a, b)) return true
        val x = norm(a)
        val y = norm(b)
        return x.isNotEmpty() && y.isNotEmpty() && (x.contains(y) || y.contains(x))
    }

    private fun unescape(s: String): String =
        Html.fromHtml(s, Html.FROM_HTML_MODE_LEGACY).toString().trim()

    fun query(i: Item): String =
        if (i.kind == Kind.ARTIST) i.title else listOf(i.title, i.artist).filter { it.isNotBlank() }.joinToString(" ")

    // ---------- identify what was shared ----------

    fun identify(text: String, subject: String?): Result {
        val url = Regex("https?://\\S+").find(text)?.value?.trimEnd('.', ',', ')', '"', '\'')
        var rest = text
        if (url != null) rest = rest.replace(url, " ")
        rest = rest.replace(Regex("\\s+"), " ").trim().trim('"', '“', '”')
        if (rest.isEmpty() && !subject.isNullOrBlank()) rest = subject.trim()

        val host = url?.let { Uri.parse(it).host?.lowercase() } ?: ""
        val src = Svc.values().firstOrNull { s -> s.hosts.any { host.contains(it) } }

        var guess: Item? = null
        var exact = false
        if (url != null) {
            guess = when (src) {
                Svc.APPLE -> apple(url).also { exact = it != null }
                Svc.SPOTIFY -> spotify(url)
                Svc.YTM -> youtube(url)
                else -> page(url)
            }
        }
        if (guess == null && rest.isNotEmpty()) guess = fromText(rest)
        if (guess == null) return Result(null, src, url, "")

        val from = src?.label ?: "shared text"
        if (exact) {
            return Result(guess, src, url, "Read straight from your Apple Music link.")
        }

        val term = query(guess)
        val found = try {
            search(term, guess.kind)
        } catch (e: Exception) {
            emptyList()
        }
        val g = guess
        val best = found.firstOrNull { sameName(it.title, g.title) && (g.artist.isBlank() || looseName(it.artist, g.artist)) }
            ?: found.firstOrNull { sameName(it.title, g.title) }
            ?: found.firstOrNull()

        val read = "From your $from link: “${g.title}”" + (if (g.artist.isNotBlank()) " by ${g.artist}" else "")
        return if (best == null) {
            Result(g, src, url, "$read. Couldn’t confirm it on Apple Music — check the details.")
        } else {
            Result(best, src, url, "$read. Matched on Apple Music.")
        }
    }

    private fun fromText(rest: String): Item {
        val m = Regex("^(.+?) by (.+)$", RegexOption.IGNORE_CASE).find(rest)
        return if (m != null) Item(Kind.SONG, m.groupValues[1].trim(), m.groupValues[2].trim(), "", null, null)
        else Item(Kind.SONG, rest, "", "", null, null)
    }

    private fun apple(url: String): Item? {
        val u = Uri.parse(url)
        val segs = u.pathSegments
        val cc = segs.firstOrNull()?.takeIf { it.length == 2 } ?: "us"
        val id = u.getQueryParameter("i")
            ?: segs.lastOrNull { it.isNotEmpty() && it.all { ch -> ch.isDigit() } }
            ?: return null
        val j = getJson("https://itunes.apple.com/lookup?id=$id&country=${cc.uppercase()}") ?: return null
        val arr = j.optJSONArray("results") ?: return null
        val r = arr.optJSONObject(0) ?: return null
        return fromItunes(r)
    }

    private fun spotify(url: String): Item? {
        val html = get(url)
        if (html != null) {
            val raw = Regex("<title>(.*?)</title>", RegexOption.DOT_MATCHES_ALL).find(html)?.groupValues?.get(1)
            if (raw != null) {
                val t = unescape(raw).removeSuffix("| Spotify").trim()
                Regex("^(.+) - song (?:and lyrics )?by (.+)$").find(t)?.let {
                    return Item(Kind.SONG, it.groupValues[1].trim(), it.groupValues[2].trim(), "", null, null)
                }
                Regex("^(.+) - (?:Album|Single|EP|Compilation) by (.+)$").find(t)?.let {
                    return Item(Kind.ALBUM, it.groupValues[1].trim(), it.groupValues[2].trim(), "", null, null)
                }
                if (Uri.parse(url).path?.contains("/artist/") == true && t.isNotBlank()) {
                    return Item(Kind.ARTIST, t, "", "", null, null)
                }
            }
        }
        val j = getJson("https://open.spotify.com/oembed?url=" + Uri.encode(url)) ?: return null
        val title = j.optString("title").trim()
        return if (title.isBlank()) null else Item(Kind.SONG, title, "", "", null, null)
    }

    private fun youtube(url: String): Item? {
        val u = Uri.parse(url)
        val v = u.getQueryParameter("v") ?: if ((u.host ?: "").contains("youtu.be")) u.lastPathSegment else null
        if (v == null) return null
        val j = getJson(
            "https://www.youtube.com/oembed?format=json&url=" + Uri.encode("https://www.youtube.com/watch?v=$v")
        ) ?: return null
        var title = j.optString("title").trim()
        var artist = j.optString("author_name").removeSuffix(" - Topic").replace(Regex("(?i)vevo$"), "").trim()
        title = title.replace(
            Regex("\\s*[\\(\\[](official|lyric|lyrics|audio|video|music video|visualizer|hd|4k)[^\\)\\]]*[\\)\\]]", RegexOption.IGNORE_CASE),
            ""
        ).trim()
        val p = title.split(" - ", limit = 2)
        if (p.size == 2) {
            val left = p[0].trim()
            if (artist.isBlank() || left.equals(artist, true) || artist.contains(left, true)) {
                title = p[1].trim()
            } else {
                artist = left
                title = p[1].trim()
            }
        }
        return if (title.isBlank()) null else Item(Kind.SONG, title, artist, "", null, null)
    }

    private fun page(url: String): Item? {
        val html = get(url) ?: return null
        val og = Regex("<meta[^>]+property=[\"']og:title[\"'][^>]+content=[\"']([^\"']*)[\"']", RegexOption.IGNORE_CASE)
            .find(html)?.groupValues?.get(1)
        val raw = og ?: Regex("<title>(.*?)</title>", RegexOption.DOT_MATCHES_ALL).find(html)?.groupValues?.get(1)
        ?: return null
        var t = unescape(raw)
        t = t.replace(
            Regex("\\s*[|\\u2013-]\\s*(Spotify|TIDAL|Tidal|Deezer|SoundCloud|Amazon Music|YouTube Music).*$"), ""
        ).replace(Regex("(?i)\\s+on\\s+(tidal|deezer|soundcloud)$"), "").trim()
        if (t.isBlank()) return null
        return fromText(t)
    }

    // ---------- iTunes ----------

    private fun fromItunes(r: JSONObject): Item? {
        fun art(): String? {
            val a = r.optString("artworkUrl100")
            return if (a.isBlank()) null else a.replace("100x100bb", "400x400bb")
        }
        return when (r.optString("wrapperType")) {
            "track" -> Item(
                Kind.SONG, r.optString("trackName"), r.optString("artistName"),
                r.optString("collectionName"), art(), r.optString("trackViewUrl").ifBlank { null }
            )
            "collection" -> Item(
                Kind.ALBUM, r.optString("collectionName"), r.optString("artistName"),
                "", art(), r.optString("collectionViewUrl").ifBlank { null }
            )
            "artist" -> Item(
                Kind.ARTIST, r.optString("artistName"), "", "", null,
                r.optString("artistLinkUrl").ifBlank { null }
            )
            else -> null
        }
    }

    fun search(term: String, kind: Kind): List<Item> {
        val j = getJson(
            "https://itunes.apple.com/search?media=music&limit=8&entity=${kind.entity}&term=" + Uri.encode(term)
        ) ?: return emptyList()
        val arr = j.optJSONArray("results") ?: return emptyList()
        val out = ArrayList<Item>()
        for (n in 0 until arr.length()) {
            val o = arr.optJSONObject(n) ?: continue
            val it = fromItunes(o) ?: continue
            if (it.kind == kind && it.title.isNotBlank()) out.add(it)
        }
        return out
    }

    // ---------- links for every service ----------

    private fun deezer(item: Item): String? {
        val t = item.title.replace("\"", " ")
        val a = item.artist.replace("\"", " ")
        val path: String
        val q: String
        when (item.kind) {
            Kind.SONG -> { path = "track"; q = if (a.isBlank()) t else "artist:\"$a\" track:\"$t\"" }
            Kind.ALBUM -> { path = "album"; q = if (a.isBlank()) t else "artist:\"$a\" album:\"$t\"" }
            Kind.ARTIST -> { path = "artist"; q = t }
        }
        val j = getJson("https://api.deezer.com/search/$path?limit=4&q=" + Uri.encode(q)) ?: return null
        val arr = j.optJSONArray("data") ?: return null
        for (n in 0 until arr.length()) {
            val o = arr.optJSONObject(n) ?: continue
            val name = if (item.kind == Kind.ARTIST) o.optString("name") else o.optString("title")
            if (!sameName(name, item.title)) continue
            if (item.kind != Kind.ARTIST && item.artist.isNotBlank()) {
                val an = o.optJSONObject("artist")?.optString("name") ?: ""
                if (!looseName(an, item.artist)) continue
            }
            val link = o.optString("link")
            if (link.isNotBlank()) return link.substringBefore("?")
        }
        return null
    }

    private fun clean(s: Svc, url: String): String =
        if (s == Svc.SPOTIFY) url.substringBefore('?') else url

    fun rows(item: Item, src: Svc?, orig: String?): List<LinkRow> {
        val q = query(item)
        val dz = try { deezer(item) } catch (e: Exception) { null }
        val ap = item.appleUrl?.takeIf { it.isNotBlank() }
        return Svc.values().map { s ->
            when {
                s == src && orig != null -> LinkRow(s, clean(s, orig), true, "Original link")
                s == Svc.APPLE && ap != null -> LinkRow(s, ap, true, "Exact link")
                s == Svc.DEEZER && dz != null -> LinkRow(s, dz, true, "Exact link")
                else -> LinkRow(s, s.search(q), false, "Search link")
            }
        }
    }
}
