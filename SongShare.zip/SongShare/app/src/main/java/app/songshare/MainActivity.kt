package app.songshare

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private enum class Phase { EMPTY, LOADING, RESULT }

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var scroll: ScrollView
    private lateinit var col: LinearLayout

    // colours
    private var dark = false
    private var bgC = 0
    private var cardC = 0
    private var chipC = 0
    private var textC = 0
    private var subC = 0
    private var accent = 0
    private var onAccent = Color.WHITE
    private val green = 0xFF2EAD5A.toInt()

    // state
    private var phase = Phase.EMPTY
    private var gen = 0
    private var rowGen = 0
    private var artGen = 0
    private var fixGen = 0

    private var item: Item? = null
    private var source: Svc? = null
    private var origUrl: String? = null
    private var caption = ""
    private var art: Bitmap? = null
    private var rows: List<LinkRow> = emptyList()
    private var rowsBusy = false

    private var fixOpen = false
    private var fixKind = Kind.SONG
    private var fixQuery = ""
    private var fixResults: List<Item> = emptyList()
    private var fixBusy = false
    private var fixSearched = false
    private var fixInput: EditText? = null

    private var artView: ImageView? = null
    private val copyLabels = HashMap<Svc, TextView>()

    // ---------- lifecycle ----------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dark = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        bgC = (if (dark) 0xFF0E1013L else 0xFFF4F5F8L).toInt()
        cardC = (if (dark) 0xFF181B21L else 0xFFFFFFFFL).toInt()
        chipC = (if (dark) 0xFF242830L else 0xFFEBEDF2L).toInt()
        textC = (if (dark) 0xFFF2F4F8L else 0xFF14161AL).toInt()
        subC = (if (dark) 0xFF9AA3B2L else 0xFF677084L).toInt()
        accent = (if (dark) 0xFF7C9CFFL else 0xFF3F63E0L).toInt()
        onAccent = if (dark) 0xFF0E1013.toInt() else Color.WHITE

        window.setDecorFitsSystemWindows(false)
        window.setBackgroundDrawable(ColorDrawable(bgC))
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        val light = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or
            WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
        window.insetsController?.setSystemBarsAppearance(if (dark) 0 else light, light)

        scroll = ScrollView(this)
        scroll.isFillViewport = true
        scroll.setOnApplyWindowInsetsListener { v, ins ->
            val b = ins.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.ime())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            ins
        }
        col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(12), dp(20), dp(28))
        scroll.addView(col, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(scroll)

        render()
        if (savedInstanceState == null) handle(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handle(intent)
    }

    private fun handle(i: Intent?) {
        if (i != null && i.action == Intent.ACTION_SEND && i.type?.startsWith("text/") == true) {
            val text = i.getStringExtra(Intent.EXTRA_TEXT) ?: ""
            val subj = i.getStringExtra(Intent.EXTRA_SUBJECT) ?: i.getStringExtra(Intent.EXTRA_TITLE)
            if (text.isNotBlank()) {
                start(text, subj)
                return
            }
        }
    }

    // ---------- flow ----------

    private fun start(text: String, subj: String?) {
        val g = ++gen
        rowGen++
        phase = Phase.LOADING
        item = null
        rows = emptyList()
        art = null
        fixOpen = false
        fixResults = emptyList()
        fixSearched = false
        render()
        Thread {
            val res = try {
                Resolver.identify(text, subj)
            } catch (e: Exception) {
                Resolver.Result(null, null, null, "")
            }
            ui.post {
                if (g == gen && !isDestroyed) {
                    source = res.source
                    origUrl = res.origUrl
                    phase = Phase.RESULT
                    val found = res.item
                    item = found
                    if (found == null) {
                        caption = "Couldn’t work out the song from that share. Search for it below."
                        fixOpen = true
                        fixKind = Kind.SONG
                        fixQuery = ""
                        render()
                    } else {
                        caption = res.note
                        loadArt(found)
                        computeRows()
                        render()
                    }
                }
            }
        }.start()
    }

    private fun pick(i: Item) {
        item = i
        phase = Phase.RESULT
        caption = "Picked by you."
        fixOpen = false
        fixResults = emptyList()
        fixSearched = false
        loadArt(i)
        computeRows()
        render()
    }

    private fun loadArt(i: Item) {
        art = null
        val u = i.art ?: return
        val g = ++artGen
        Thread {
            val b = Resolver.bitmap(u)
            ui.post {
                if (g == artGen && !isDestroyed && b != null) {
                    art = b
                    artView?.setImageBitmap(b)
                }
            }
        }.start()
    }

    private fun computeRows() {
        val i = item ?: return
        val g = ++rowGen
        val s = source
        val o = origUrl
        rowsBusy = true
        rows = emptyList()
        Thread {
            val r = try {
                Resolver.rows(i, s, o)
            } catch (e: Exception) {
                emptyList()
            }
            ui.post {
                if (g == rowGen && !isDestroyed) {
                    rows = r
                    rowsBusy = false
                    render()
                }
            }
        }.start()
    }

    private fun openFix() {
        val i = item
        fixOpen = true
        fixSearched = false
        fixResults = emptyList()
        if (i != null) {
            fixKind = i.kind
            fixQuery = Resolver.query(i)
            render()
            runFix()
        } else {
            render()
        }
    }

    private fun runFix() {
        val q = (fixInput?.text?.toString() ?: fixQuery).trim()
        if (q.isEmpty()) return
        fixQuery = q
        fixBusy = true
        fixSearched = false
        fixResults = emptyList()
        val g = ++fixGen
        val k = fixKind
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(scroll.windowToken, 0)
        render()
        Thread {
            val r = try {
                Resolver.search(q, k)
            } catch (e: Exception) {
                emptyList()
            }
            ui.post {
                if (g == fixGen && !isDestroyed) {
                    fixResults = r
                    fixBusy = false
                    fixSearched = true
                    render()
                }
            }
        }.start()
    }

    private fun copy(r: LinkRow) {
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("Song link", r.url))
        val t = copyLabels[r.svc] ?: return
        t.text = "Copied ✓"
        t.setTextColor(green)
        ui.postDelayed({
            t.text = "Copy"
            t.setTextColor(accent)
        }, 1600)
    }

    private fun open(r: LinkRow) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(r.url)))
        } catch (e: Exception) {
        }
    }

    // ---------- rendering ----------

    private fun render() {
        fixInput?.let { fixQuery = it.text.toString() }
        fixInput = null
        artView = null
        copyLabels.clear()
        col.removeAllViews()

        col.addView(header())

        when (phase) {
            Phase.LOADING -> col.addView(loadingView())
            Phase.EMPTY -> {
                col.addView(emptyCard())
                col.addView(fixPanel())
            }
            Phase.RESULT -> {
                val i = item
                if (i == null) {
                    col.addView(messageCard(caption))
                    col.addView(fixPanel())
                } else {
                    col.addView(matchCard(i))
                    if (fixOpen) col.addView(fixPanel())
                    col.addView(sectionLabel("Tap a service to copy its link  ·  hold to open"))
                    if (rowsBusy) {
                        col.addView(tv("Finding links…", 14f, subC, false).apply {
                            setPadding(dp(4), dp(8), 0, 0)
                        })
                    } else {
                        for (r in rows) col.addView(linkRow(r))
                    }
                }
            }
        }
    }

    private fun header(): View {
        val h = tv("Song Share", 28f, textC, true)
        h.setPadding(dp(2), dp(8), 0, dp(16))
        return h
    }

    private fun loadingView(): View {
        val box = card()
        box.gravity = Gravity.CENTER
        box.setPadding(dp(16), dp(36), dp(16), dp(36))
        box.addView(ProgressBar(this))
        box.addView(tv("Finding your song…", 15f, subC, false).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(14), 0, 0)
        })
        return box
    }

    private fun emptyCard(): View {
        val box = card()
        box.addView(tv("Share a song here", 20f, textC, true))
        box.addView(tv(
            "In Apple Music, Spotify or any music app, tap Share on a song, album or artist and pick Song Share. " +
                "You’ll get a link for every service to copy.",
            14.5f, subC, false
        ).apply { setPadding(0, dp(8), 0, 0) })
        return box
    }

    private fun messageCard(msg: String): View {
        val box = card()
        box.addView(tv(msg, 15f, textC, false))
        return box
    }

    private fun matchCard(i: Item): View {
        val box = card()

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL

        val frame = FrameLayout(this)
        frame.background = round(chipC, 16)
        frame.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) {
                o.setRoundRect(0, 0, v.width, v.height, dp(16).toFloat())
            }
        }
        frame.clipToOutline = true
        val letter = tv(i.title.take(1).uppercase(), 30f, subC, true)
        letter.gravity = Gravity.CENTER
        frame.addView(letter, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val img = ImageView(this)
        img.scaleType = ImageView.ScaleType.CENTER_CROP
        art?.let { img.setImageBitmap(it) }
        frame.addView(img, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        artView = img
        top.addView(frame, LinearLayout.LayoutParams(dp(92), dp(92)))

        val info = LinearLayout(this)
        info.orientation = LinearLayout.VERTICAL
        info.setPadding(dp(16), 0, 0, 0)
        info.addView(tv(i.kind.label.uppercase(), 11.5f, accent, true).apply { letterSpacing = 0.12f })
        info.addView(tv(i.title, 20f, textC, true).apply {
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            setPadding(0, dp(3), 0, 0)
        })
        if (i.artist.isNotBlank()) {
            info.addView(tv(i.artist, 15f, subC, false).apply {
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                setPadding(0, dp(2), 0, 0)
            })
        }
        if (i.album.isNotBlank()) {
            info.addView(tv(i.album, 13f, subC, false).apply {
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                setPadding(0, dp(1), 0, 0)
            })
        }
        top.addView(info, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        box.addView(top)

        if (caption.isNotBlank()) {
            box.addView(tv(caption, 12.5f, subC, false).apply { setPadding(0, dp(14), 0, 0) })
        }

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(0, dp(12), 0, 0)
        bar.addView(
            tv("Is this the right ${i.kind.label.lowercase()}?", 14f, textC, true),
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        val btn = tv(if (fixOpen) "Close" else "Not it", 13.5f, accent, true)
        btn.gravity = Gravity.CENTER
        btn.setPadding(dp(16), dp(8), dp(16), dp(8))
        btn.background = round(chipC, 20)
        btn.setOnClickListener {
            if (fixOpen) {
                fixOpen = false
                render()
            } else {
                openFix()
            }
        }
        bar.addView(btn)
        box.addView(bar)
        return box
    }

    private fun fixPanel(): View {
        val box = card()
        val hasItem = item != null
        box.addView(tv(if (hasItem) "Find the right one" else "Search by hand", 15f, textC, true))

        val chips = LinearLayout(this)
        chips.orientation = LinearLayout.HORIZONTAL
        chips.setPadding(0, dp(10), 0, dp(10))
        for (k in Kind.values()) {
            val on = k == fixKind
            val c = tv(k.label, 13.5f, if (on) onAccent else textC, true)
            c.gravity = Gravity.CENTER
            c.setPadding(dp(14), dp(7), dp(14), dp(7))
            c.background = round(if (on) accent else chipC, 20)
            c.setOnClickListener {
                fixKind = k
                fixResults = emptyList()
                fixSearched = false
                render()
                if (fixQuery.isNotBlank()) runFix()
            }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.rightMargin = dp(8)
            chips.addView(c, lp)
        }
        box.addView(chips)

        val input = EditText(this)
        input.setText(fixQuery)
        input.hint = "Song, album or artist"
        input.setSingleLine()
        input.imeOptions = EditorInfo.IME_ACTION_SEARCH
        input.setTextColor(textC)
        input.setHintTextColor(subC)
        input.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        input.background = round(chipC, 12)
        input.setPadding(dp(14), dp(12), dp(14), dp(12))
        input.setOnEditorActionListener { _, a, _ ->
            if (a == EditorInfo.IME_ACTION_SEARCH) {
                runFix()
                true
            } else {
                false
            }
        }
        fixInput = input
        box.addView(input, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val go = tv("Search", 15f, onAccent, true)
        go.gravity = Gravity.CENTER
        go.setPadding(0, dp(12), 0, dp(12))
        go.background = round(accent, 12)
        go.setOnClickListener { runFix() }
        val glp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        glp.topMargin = dp(10)
        box.addView(go, glp)

        if (fixBusy) {
            box.addView(tv("Searching…", 14f, subC, false).apply { setPadding(dp(2), dp(12), 0, 0) })
        } else if (fixSearched && fixResults.isEmpty()) {
            box.addView(tv("No matches. Try different words.", 14f, subC, false).apply { setPadding(dp(2), dp(12), 0, 0) })
        }
        for (r in fixResults) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.VERTICAL
            row.setPadding(dp(14), dp(10), dp(14), dp(10))
            row.background = round(chipC, 12)
            row.addView(tv(r.title, 15f, textC, true).apply {
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            })
            val sub = listOf(r.artist, r.album).filter { it.isNotBlank() }.joinToString("  ·  ")
            if (sub.isNotEmpty()) {
                row.addView(tv(sub, 12.5f, subC, false).apply {
                    maxLines = 1
                    ellipsize = TextUtils.TruncateAt.END
                })
            }
            row.setOnClickListener { pick(r) }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dp(8)
            box.addView(row, lp)
        }
        return box
    }

    private fun sectionLabel(s: String): View {
        val t = tv(s, 12.5f, subC, true)
        t.setPadding(dp(4), dp(6), 0, dp(4))
        return t
    }

    private fun linkRow(r: LinkRow): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(14), dp(12), dp(16), dp(12))
        row.background = round(cardC, 16)

        val badge = tv(r.svc.label.take(1), 16f, Color.WHITE, true)
        badge.gravity = Gravity.CENTER
        badge.background = round(r.svc.color, 18)
        row.addView(badge, LinearLayout.LayoutParams(dp(36), dp(36)))

        val mid = LinearLayout(this)
        mid.orientation = LinearLayout.VERTICAL
        mid.setPadding(dp(14), 0, dp(8), 0)
        mid.addView(tv(r.svc.label, 16f, textC, true))
        mid.addView(tv(r.note, 12.5f, if (r.exact) green else subC, false))
        row.addView(mid, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        val trail = tv("Copy", 14f, accent, true)
        row.addView(trail)
        copyLabels[r.svc] = trail

        row.setOnClickListener { copy(r) }
        row.setOnLongClickListener {
            open(r)
            true
        }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(8)
        row.layoutParams = lp
        return row
    }

    // ---------- helpers ----------

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(16), dp(16), dp(16), dp(16))
        c.background = round(cardC, 20)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = dp(14)
        c.layoutParams = lp
        return c
    }

    private fun tv(s: String, size: Float, color: Int, bold: Boolean): TextView {
        val t = TextView(this)
        t.text = s
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
        t.setTextColor(color)
        if (bold) t.typeface = Typeface.DEFAULT_BOLD
        return t
    }

    private fun round(color: Int, r: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(r).toFloat()
        return g
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
